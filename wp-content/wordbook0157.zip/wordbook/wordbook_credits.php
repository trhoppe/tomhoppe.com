<?php

function wordbook_option_credits_render($donors) {
?>

    <div style="float: left; vertical-align: top; margin-right: 1em;">

    <ul>

<?php
    foreach ($donors as $url => $title) {
?>

        <li>
        <a href="<?php echo $url; ?>" target="_blank">
        <?php echo $title; ?>
        </a>
        </li>

<?php
    }
?>

    </ul>

    </div>

<?php
}

function wordbook_option_credits() {
    $donors = array(
        'http://thecamaras.net/' => 'The Camaras',
        'http://www.steve-c.co.uk/' => "Steve's Space",
        'http://alex.tsaiberspace.net/' => 'The .Plan',
        'http://drunkencomputing.com/' => 'drunkencomputing',
        'http://trentadams.com/' => 'life by way of media',
        'http://www.mounthermon.org/' => 'Mount Hermon',
        'http://superjudas.net/' => 'Superjudas bloggt',
        'http://blog.ofsteel.net/' => 'Blood, Glory & Steel',
        'http://shashikiran.com/' => 'itinerant',
        'http://www.patricksimpson.nl/' => 'Patrick Simpson',
        'http://hippocratesinsandiego.com/' => 'Hippocrates in San Diego',
        'http://www.peterbakke.com/' => "It's a Small World After All",
        'http://www.missmentor.com/' => 'Miss Mentor',
        'http://garysaid.com/' => 'Gary Said',
        'http://formbet.co.uk/' => 'Daily Horse Racing Ratings & Analysis',
        'http://www.interactivewebs.com/' => 'Interactive Webs',
        'http://blog.freetobelean.com/wordpress' =>
                'Achieve and Maintain Optimal Health',
        'http://www.officetipsandmethods.com/' => 'Office Tips and Methods',
        'http://www.marcuseast.org/' => 'Marcus East',
        );
    $off = (count($donors) + 1) / 2;
    $left = array_slice($donors, 0, $off);
    $right = array_slice($donors, $off);
?>

<h3><?php _e('Thanks'); ?></h3>
<div class="wordbook_thanks">

    Special thanks to:

    <div>

<?php

    wordbook_option_credits_render($left);
    wordbook_option_credits_render($right);

?>

    </div>

    <div style="clear: left;">&nbsp;</div>

    If you find this plugin useful, please consider making a donation to
    support its continued development; any amount is welcome (for
    acknowledgement, please provide your URL as a note on the PayPal form):

    <div style="text-align: center; margin: 1em auto;">
        <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
            <input type="hidden" name="cmd" value="_s-xclick">
            <input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but21.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
            <img alt="" border="0"
                src="https://www.paypal.com/en_US/i/scr/pixel.gif"
                width="1" height="1">
            <input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIHLwYJKoZIhvcNAQcEoIIHIDCCBxwCAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYBUWkHYpAwvakglczL/Ad59cRgEq2dUA2rwW8Y7gwHExMnOJn1f7guOWKhkMd/yepZypX5SSVjdvioyJDJCyuyotidiyCdQes0fc1AwI1CEsdAP6dJD/02B3heGlbQmxoNPYKXIzhKUGN5zUVCJCrQkq6BBYpvx5cgJnPMor+koyzELMAkGBSsOAwIaBQAwgawGCSqGSIb3DQEHATAUBggqhkiG9w0DBwQIrBbFtSlBYJWAgYiz+/4bpOww9Hsw0a4j45Y5eeHKeqUNPiHmZT4RE0q4JPgHnP8FshcJiRXlNOwK99u9dX8C5KEk9mrLNHdc4QYMrjUWqVSmCKWYQCOudTGMas5q940y+vMaxAUqI0xHAZCvYm8xf4/+z4yGGkRSesObV7Lh0QEDlJ2/Eq/D8tZGxavK8roLvT2poIIDhzCCA4MwggLsoAMCAQICAQAwDQYJKoZIhvcNAQEFBQAwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tMB4XDTA0MDIxMzEwMTMxNVoXDTM1MDIxMzEwMTMxNVowgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDBR07d/ETMS1ycjtkpkvjXZe9k+6CieLuLsPumsJ7QC1odNz3sJiCbs2wC0nLE0uLGaEtXynIgRqIddYCHx88pb5HTXv4SZeuv0Rqq4+axW9PLAAATU8w04qqjaSXgbGLP3NmohqM6bV9kZZwZLR/klDaQGo1u9uDb9lr4Yn+rBQIDAQABo4HuMIHrMB0GA1UdDgQWBBSWn3y7xm8XvVk/UtcKG+wQ1mSUazCBuwYDVR0jBIGzMIGwgBSWn3y7xm8XvVk/UtcKG+wQ1mSUa6GBlKSBkTCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb22CAQAwDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQUFAAOBgQCBXzpWmoBa5e9fo6ujionW1hUhPkOBakTr3YCDjbYfvJEiv/2P+IobhOGJr85+XHhN0v4gUkEDI8r2/rNk1m0GA8HKddvTjyGw/XqXa+LSTlDYkqI8OwR8GEYj4efEtcRpRYBxV8KxAW93YDWzFGvruKnnLbDAF6VR5w/cCMn5hzGCAZowggGWAgEBMIGUMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMDcwODIzMDUzMTE3WjAjBgkqhkiG9w0BCQQxFgQUpvpxTNUCpKTewgppBRTWYi2GpX8wDQYJKoZIhvcNAQEBBQAEgYBRJa2+lvwQ0xUIE3h+PLjZQDceUblOgBcj/0gD/BD9T2sxS1RrlDg0P6HujD9DS83gmmt79FGuX0okwtdLp4a7N+5IgdJdshGymMY07cHxQjcNBoXyQH24PRYW9CPCJ0Rfeqj5b0KHO/TB2pvMTg0qW7AmbtIotpC4qAVJ+buHHA==-----END PKCS7-----
">
        </form>
    </div>
</div>

<?php
}

// vim:et sw=4 ts=8
?>
